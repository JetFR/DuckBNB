import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


@NgModule({
  declarations: [
    ModifPage,
  ],
  imports: [
    IonicPageModule.forChild(ModifPage),
  ],
})
export class ModifPage {}
